-- phpMyAdmin SQL Dump
-- version 5.0.2
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1:3306
-- Generation Time: Aug 05, 2021 at 09:37 PM
-- Server version: 5.7.31
-- PHP Version: 7.3.21

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `spu_forms`
--

-- --------------------------------------------------------

--
-- Table structure for table `forms_info`
--

DROP TABLE IF EXISTS `forms_info`;
CREATE TABLE IF NOT EXISTS `forms_info` (
  `First_name` text NOT NULL,
  `Last_name` text NOT NULL,
  `DOB` date NOT NULL,
  `Citizenship` text NOT NULL,
  `Country_Birth` text NOT NULL,
  `County_Birth` text NOT NULL,
  `ID` bigint(15) NOT NULL,
  `Gender` text NOT NULL,
  `High_L_Education` text NOT NULL,
  `Course` varchar(50) NOT NULL,
  `P_Address` varchar(50) NOT NULL,
  `Town` text NOT NULL,
  `Telephone` bigint(20) NOT NULL,
  `Mobile_No` bigint(20) NOT NULL,
  `Email` varchar(50) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
