<!DOCTYPE html>
<html>
<head>
	<title>Results</title>
	<style>
		#header
		{
			border: solid;
			background: #9e2e34;
			border-radius: 10px;
			margin: 50px;
		}
		#header h1
		{
			color: white;
			font: Times New Roman;
			font-style: italic;
			text-align: center;
			text-shadow: 5px 5px 15px;
		}
		#header:hover
		{
			font-size: 20px;
			transition: 0.8s;
		}
	</style>

</head>
<body>
	<div id=header>
	<?php
		//Getting the input from index
		// $First_name=$_POST['first-name'];
		// $Last_name=$_POST['last-name'];
		// $DOB=$_POST['date'];
		// $Citizenship=$_POST['citizenship'];
		// $Country_Birth=$_POST['countryofbirth'];
		// $ID=$_POST['ID'];
		// $Gender=$_POST['Gender'];
		// $High_L_Education=$_POST['L_Education'];
		// $P_Address=$_POST['postaladdress'];
		// $Town=$_POST['town'];
		// $Telephone=$_POST['telephone'];
		// $Mobile_No=$_POST['mobile'];
		// $Email=$_POST['email'];

		//Sending data into the database
		//$link=mysqli_connect("hostname", "username", "password", "database");
		$link=mysqli_connect("localhost","root","","spu_forms");
		//Checking Connections
		if($link===false)
		{
			die("Could not connect!".mysqli_connect_error());
		};
		$First_name=mysqli_real_escape_string($link, $_POST['first-name']);
		$Last_name=mysqli_real_escape_string($link, $_POST['last-name']);
		$DOB=mysqli_real_escape_string($link, $_POST['date']);
		$Citizenship=mysqli_real_escape_string($link, $_POST['citizenship']);
		$Country_Birth=mysqli_real_escape_string($link, $_POST['countryofbirth']);
		$County_Birth=mysqli_real_escape_string($link, $_POST['countyofbirth']);
		$ID=mysqli_real_escape_string($link, $_POST['ID']);
		$Gender=mysqli_real_escape_string($link, $_POST['Gender']);
		$High_L_Education=mysqli_real_escape_string($link, $_POST['L_Education']);
		$Course=mysqli_real_escape_string($link, $_POST['course']);
		$P_Address=mysqli_real_escape_string($link, $_POST['postaladdress']);
		$Town=mysqli_real_escape_string($link, $_POST['town']);
		$Telephone=mysqli_real_escape_string($link, $_POST['telephone']);
		$Mobile_No=mysqli_real_escape_string($link, $_POST['mobile']);
		$Email=mysqli_real_escape_string($link, $_POST['email']);
		

		//Inserting data into the database
		$Ins1="INSERT INTO forms_info(First_name, Last_name, DOB, Citizenship, Country_Birth, County_Birth, ID, Gender, High_L_Education, Course, P_Address, Town, Telephone, Mobile_No, Email)
			VALUES('$First_name','$Last_name','$DOB','$Citizenship','$Country_Birth','$County_Birth',$ID,'$Gender','$High_L_Education', '$Course','$P_Address','$Town',$Telephone,$Mobile_No,'$Email')";
			if(mysqli_query($link,$Ins1))
			{
				echo "<h1>Data was successfully saved in the database</h1>";
			}
			else
			{
				echo "<h1>Could not save the data in the database</h1>".mysqli_error($link);
			}

			//Closing the connection
			mysqli_close($link);

			//Setting up the default email sending
			$headers="From: jlwambi2000@gmail.com";
			$subject="Course Registration";
			$message="Dear $Last_name $First_name, Your application has been successfully submitted for $Course. Please await the outcome in two weeks time . Yours Registrar";
			$message=wordwrap($message, 70);

			mail($Email,$subject,$message,$headers);
			
	?>
	</div>
</body>
</html>